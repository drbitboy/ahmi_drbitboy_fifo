﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    '   <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    ' <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ForceItemsIntoToolBox1 = New MfgControl.AdvancedHMI.Drivers.ForceItemsIntoToolbox()
        Me.btn_fifo_rotate = New AdvancedHMIControls.BasicButton()
        Me.EthernetIPforSLCMicroCom1 = New AdvancedHMIDrivers.EthernetIPforSLCMicroCom(Me.components)
        Me.dpm_N9_3 = New AdvancedHMIControls.DigitalPanelMeter()
        Me.lbl_click = New System.Windows.Forms.Label()
        Me.lbl_dblclick = New System.Windows.Forms.Label()
        Me.txt_EIPport = New System.Windows.Forms.TextBox()
        Me.lbl_ipaddress = New System.Windows.Forms.Label()
        CType(Me.EthernetIPforSLCMicroCom1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(6, 375)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(194, 32)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "For Development Source Code Visit" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "http://www.advancedhmi.com"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btn_fifo_rotate
        '
        Me.btn_fifo_rotate.BackColor = System.Drawing.Color.Black
        Me.btn_fifo_rotate.ComComponent = Me.EthernetIPforSLCMicroCom1
        Me.btn_fifo_rotate.ForeColor = System.Drawing.Color.Black
        Me.btn_fifo_rotate.ForeColorAltername = System.Drawing.Color.Black
        Me.btn_fifo_rotate.Highlight = False
        Me.btn_fifo_rotate.HighlightColor = System.Drawing.Color.Green
        Me.btn_fifo_rotate.Location = New System.Drawing.Point(85, 197)
        Me.btn_fifo_rotate.MaximumHoldTime = 3000
        Me.btn_fifo_rotate.MinimumHoldTime = 500
        Me.btn_fifo_rotate.Name = "btn_fifo_rotate"
        Me.btn_fifo_rotate.OutputType = MfgControl.AdvancedHMI.Controls.OutputType.MomentarySet
        Me.btn_fifo_rotate.PLCAddressClick = "B3:0/0"
        Me.btn_fifo_rotate.SelectTextAlternate = False
        Me.btn_fifo_rotate.Size = New System.Drawing.Size(168, 63)
        Me.btn_fifo_rotate.TabIndex = 75
        Me.btn_fifo_rotate.Text = "Rotate FIFO"
        Me.btn_fifo_rotate.TextAlternate = Nothing
        Me.btn_fifo_rotate.UseVisualStyleBackColor = True
        Me.btn_fifo_rotate.ValueToWrite = 0
        '
        'EthernetIPforSLCMicroCom1
        '
        Me.EthernetIPforSLCMicroCom1.CIPConnectionSize = 508
        Me.EthernetIPforSLCMicroCom1.DisableSubscriptions = False
        Me.EthernetIPforSLCMicroCom1.IniFileName = ""
        Me.EthernetIPforSLCMicroCom1.IniFileSection = Nothing
        Me.EthernetIPforSLCMicroCom1.IPAddress = "192.168.1.112"
        Me.EthernetIPforSLCMicroCom1.IsPLC5 = False
        Me.EthernetIPforSLCMicroCom1.MaxPCCCPacketSize = 236
        Me.EthernetIPforSLCMicroCom1.PollRateOverride = 500
        Me.EthernetIPforSLCMicroCom1.Port = 44818
        Me.EthernetIPforSLCMicroCom1.RoutePath = Nothing
        Me.EthernetIPforSLCMicroCom1.Timeout = 5000
        '
        'dpm_N9_3
        '
        Me.dpm_N9_3.BackColor = System.Drawing.Color.Transparent
        Me.dpm_N9_3.ComComponent = Me.EthernetIPforSLCMicroCom1
        Me.dpm_N9_3.DecimalPosition = 0
        Me.dpm_N9_3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dpm_N9_3.ForeColor = System.Drawing.Color.LightGray
        Me.dpm_N9_3.KeypadFontColor = System.Drawing.Color.WhiteSmoke
        Me.dpm_N9_3.KeypadMaxValue = 0R
        Me.dpm_N9_3.KeypadMinValue = 0R
        Me.dpm_N9_3.KeypadScaleFactor = 1.0R
        Me.dpm_N9_3.KeypadText = Nothing
        Me.dpm_N9_3.KeypadWidth = 300
        Me.dpm_N9_3.Location = New System.Drawing.Point(85, 118)
        Me.dpm_N9_3.Name = "dpm_N9_3"
        Me.dpm_N9_3.NumberOfDigits = 5
        Me.dpm_N9_3.PLCAddressKeypad = ""
        Me.dpm_N9_3.PLCAddressValue = "N9:3"
        Me.dpm_N9_3.Resolution = New Decimal(New Integer() {1, 0, 0, 0})
        Me.dpm_N9_3.Size = New System.Drawing.Size(168, 73)
        Me.dpm_N9_3.TabIndex = 74
        Me.dpm_N9_3.Text = "N9:3"
        Me.dpm_N9_3.Value = 0R
        Me.dpm_N9_3.ValueScaleFactor = New Decimal(New Integer() {1, 0, 0, 0})
        Me.dpm_N9_3.ValueScaleOffset = New Decimal(New Integer() {0, 0, 0, 0})
        '
        'lbl_click
        '
        Me.lbl_click.AutoSize = True
        Me.lbl_click.ForeColor = System.Drawing.Color.White
        Me.lbl_click.Location = New System.Drawing.Point(13, 79)
        Me.lbl_click.Name = "lbl_click"
        Me.lbl_click.Size = New System.Drawing.Size(328, 18)
        Me.lbl_click.TabIndex = 76
        Me.lbl_click.Text = "Single-click meter to change to next N9 Integer"
        '
        'lbl_dblclick
        '
        Me.lbl_dblclick.AutoSize = True
        Me.lbl_dblclick.ForeColor = System.Drawing.Color.White
        Me.lbl_dblclick.Location = New System.Drawing.Point(18, 97)
        Me.lbl_dblclick.Name = "lbl_dblclick"
        Me.lbl_dblclick.Size = New System.Drawing.Size(317, 18)
        Me.lbl_dblclick.TabIndex = 77
        Me.lbl_dblclick.Text = "Double-click meter to display or update trend"
        '
        'txt_EIPport
        '
        Me.txt_EIPport.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_EIPport.Location = New System.Drawing.Point(30, 31)
        Me.txt_EIPport.Name = "txt_EIPport"
        Me.txt_EIPport.Size = New System.Drawing.Size(311, 30)
        Me.txt_EIPport.TabIndex = 78
        Me.txt_EIPport.Text = "192.168.1."
        '
        'lbl_ipaddress
        '
        Me.lbl_ipaddress.AutoSize = True
        Me.lbl_ipaddress.ForeColor = System.Drawing.Color.White
        Me.lbl_ipaddress.Location = New System.Drawing.Point(27, 9)
        Me.lbl_ipaddress.Name = "lbl_ipaddress"
        Me.lbl_ipaddress.Size = New System.Drawing.Size(319, 18)
        Me.lbl_ipaddress.TabIndex = 79
        Me.lbl_ipaddress.Text = "Complete IP address of MicrLogix 1100 PLC"
        '
        'MainForm
        '
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(358, 274)
        Me.Controls.Add(Me.lbl_ipaddress)
        Me.Controls.Add(Me.txt_EIPport)
        Me.Controls.Add(Me.lbl_dblclick)
        Me.Controls.Add(Me.lbl_click)
        Me.Controls.Add(Me.btn_fifo_rotate)
        Me.Controls.Add(Me.dpm_N9_3)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.ForeColor = System.Drawing.Color.Black
        Me.KeyPreview = True
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "drbitboy_simple_trend"
        CType(Me.EthernetIPforSLCMicroCom1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DF1ComWF1 As AdvancedHMIDrivers.SerialDF1forSLCMicroCom
    Friend WithEvents ForceItemsIntoToolBox1 As MfgControl.AdvancedHMI.Drivers.ForceItemsIntoToolbox
    Friend WithEvents EthernetIPforSLCMicroCom1 As AdvancedHMIDrivers.EthernetIPforSLCMicroCom
    Friend WithEvents dpm_N9_3 As AdvancedHMIControls.DigitalPanelMeter
    Friend WithEvents btn_fifo_rotate As AdvancedHMIControls.BasicButton
    Friend WithEvents lbl_click As Label
    Friend WithEvents lbl_dblclick As Label
    Friend WithEvents txt_EIPport As TextBox
    Friend WithEvents lbl_ipaddress As Label
End Class
