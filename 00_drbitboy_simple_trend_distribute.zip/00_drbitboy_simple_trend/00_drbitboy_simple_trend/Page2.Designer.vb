﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Page2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BasicTrendChart1 = New AdvancedHMIControls.BasicTrendChart()
        Me.EthernetIPforSLCMicroCom1 = New AdvancedHMIDrivers.EthernetIPforSLCMicroCom(Me.components)
        CType(Me.EthernetIPforSLCMicroCom1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(297, 277)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(136, 36)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BasicTrendChart1
        '
        Me.BasicTrendChart1.BackColor = System.Drawing.Color.Black
        Me.BasicTrendChart1.ComComponent = Me.EthernetIPforSLCMicroCom1
        Me.BasicTrendChart1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.BasicTrendChart1.Location = New System.Drawing.Point(3, 12)
        Me.BasicTrendChart1.MaxPoints = 100
        Me.BasicTrendChart1.Name = "BasicTrendChart1"
        Me.BasicTrendChart1.PLCAddressValue = "N9:3"
        Me.BasicTrendChart1.PLCAddressVisible = ""
        Me.BasicTrendChart1.Size = New System.Drawing.Size(725, 259)
        Me.BasicTrendChart1.TabIndex = 76
        Me.BasicTrendChart1.Text = "BasicTrendChart1"
        Me.BasicTrendChart1.Value = ""
        Me.BasicTrendChart1.YMaximum = 6
        Me.BasicTrendChart1.YMinimum = -1
        '
        'EthernetIPforSLCMicroCom1
        '
        Me.EthernetIPforSLCMicroCom1.CIPConnectionSize = 508
        Me.EthernetIPforSLCMicroCom1.DisableSubscriptions = False
        Me.EthernetIPforSLCMicroCom1.IniFileName = ""
        Me.EthernetIPforSLCMicroCom1.IniFileSection = Nothing
        Me.EthernetIPforSLCMicroCom1.IPAddress = "192.168.1.112"
        Me.EthernetIPforSLCMicroCom1.IsPLC5 = False
        Me.EthernetIPforSLCMicroCom1.MaxPCCCPacketSize = 236
        Me.EthernetIPforSLCMicroCom1.PollRateOverride = 500
        Me.EthernetIPforSLCMicroCom1.Port = 44818
        Me.EthernetIPforSLCMicroCom1.RoutePath = Nothing
        Me.EthernetIPforSLCMicroCom1.Timeout = 5000
        '
        'Page2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(732, 310)
        Me.Controls.Add(Me.BasicTrendChart1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Page2"
        Me.Tag = "2"
        Me.Text = "Page 2"
        CType(Me.EthernetIPforSLCMicroCom1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents BasicTrendChart1 As AdvancedHMIControls.BasicTrendChart
    Friend WithEvents EthernetIPforSLCMicroCom1 As AdvancedHMIDrivers.EthernetIPforSLCMicroCom
End Class
