﻿Public Class MainForm
    '*******************************************************************************
    '* Stop polling when the form is not visible in order to reduce communications
    '* Copy this section of code to every new form created
    '*******************************************************************************
    Private NotFirstShow As Boolean

    Private Sub Form_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
        '* Do not start comms on first show in case it was set to disable in design mode
        If NotFirstShow Then
            AdvancedHMIDrivers.Utilities.StopComsOnHidden(components, Me)
        Else
            NotFirstShow = True
        End If
    End Sub

    '***************************************************************
    '* .NET does not close hidden forms, so do it here
    '* to make sure forms are disposed and drivers close
    '***************************************************************
    Private Sub MainForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim index As Integer
        While index < My.Application.OpenForms.Count
            If My.Application.OpenForms(index) IsNot Me Then
                My.Application.OpenForms(index).Close()
            End If
            index += 1
        End While
    End Sub

    Dim save_tag As String

    Private Sub DigitalPanelMeter1_Click(sender As Object, e As EventArgs) Handles dpm_N9_3.Click
        Dim c1 As String
        save_tag = dpm_N9_3.Text
        c1 = save_tag.Substring(3, 1)
        If c1 > "4" Then
            c1 = "0"
        Else
            c1 = Chr(1 + Asc(c1))
        End If
        dpm_N9_3.Text = "N9:" + c1
        dpm_N9_3.PLCAddressValue = dpm_N9_3.Text
    End Sub

    Private Sub dpm_N9_3_DoubleClick(sender As Object, e As EventArgs) Handles dpm_N9_3.DoubleClick
        dpm_N9_3.Text = save_tag
        dpm_N9_3.PLCAddressValue = save_tag
        Page2.Text = save_tag
        Page2.BasicTrendChart1.PLCAddressValue = save_tag
        Page2.Show()
    End Sub

    Private Sub txt_EIPport_TextChanged(sender As Object, e As EventArgs) Handles txt_EIPport.TextChanged
        EthernetIPforSLCMicroCom1.IPAddress = txt_EIPport.Text
        Page2.EthernetIPforSLCMicroCom1.IPAddress = txt_EIPport.Text
    End Sub
End Class
